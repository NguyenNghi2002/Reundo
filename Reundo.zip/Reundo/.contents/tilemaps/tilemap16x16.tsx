<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="tilemap16x16" tilewidth="16" tileheight="16" tilecount="160" columns="8">
 <image source="reundo_16x16.png" trans="ff00ff" width="128" height="335"/>
 <tile id="0" type="player"/>
 <tile id="1" type="teleport"/>
 <tile id="2" type="box">
  <properties>
   <property name="allow_undo" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="3" type="box">
  <properties>
   <property name="allow_undo" type="bool" value="false"/>
  </properties>
 </tile>
</tileset>
